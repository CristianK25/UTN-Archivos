
  # E-commerce de Computadoras

  This is a code bundle for E-commerce de Computadoras. The original project is available at https://www.figma.com/design/fI9WUMPbGVYN4CHqq2GHEH/E-commerce-de-Computadoras.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  