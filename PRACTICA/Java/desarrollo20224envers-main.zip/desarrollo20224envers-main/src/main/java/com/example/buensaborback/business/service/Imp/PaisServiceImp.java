package com.example.buensaborback.business.service.Imp;

import com.example.buensaborback.business.service.Base.BaseServiceImp;
import com.example.buensaborback.business.service.PaisService;
import com.example.buensaborback.domain.entities.Pais;
import org.springframework.stereotype.Service;

@Service
public class PaisServiceImp extends BaseServiceImp<Pais, Long> implements PaisService {
}
