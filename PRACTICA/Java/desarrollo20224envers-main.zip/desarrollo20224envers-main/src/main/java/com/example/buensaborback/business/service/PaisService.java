package com.example.buensaborback.business.service;

import com.example.buensaborback.business.service.Base.BaseService;
import com.example.buensaborback.domain.entities.Pais;

public interface PaisService extends BaseService<Pais, Long> {
}
