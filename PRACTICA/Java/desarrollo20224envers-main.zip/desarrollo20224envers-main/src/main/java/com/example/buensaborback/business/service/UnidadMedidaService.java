package com.example.buensaborback.business.service;

import com.example.buensaborback.business.service.Base.BaseService;
import com.example.buensaborback.domain.entities.UnidadMedida;

public interface UnidadMedidaService extends BaseService<UnidadMedida,Long> {
}
