package com.example.buensaborback.domain.enums;

public enum FormaPago {
    EFECTIVO,
    MERCADO_PAGO
}
