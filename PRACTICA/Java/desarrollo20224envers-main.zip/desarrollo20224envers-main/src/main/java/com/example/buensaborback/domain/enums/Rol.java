package com.example.buensaborback.domain.enums;

public enum Rol {
    ADMIN,
    CLIENTE,
    COCINERO,
    CAJERO,
    DELIVERY
}
