package com.example.buensaborback.domain.enums;

public enum TipoEnvio {
    DELIVERY,
    TAKE_AWAY
}
