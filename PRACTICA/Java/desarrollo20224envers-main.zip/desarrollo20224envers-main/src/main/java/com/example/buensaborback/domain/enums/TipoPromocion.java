package com.example.buensaborback.domain.enums;

public enum TipoPromocion {
    HAPPY_HOUR,
    PROMOCION
}
