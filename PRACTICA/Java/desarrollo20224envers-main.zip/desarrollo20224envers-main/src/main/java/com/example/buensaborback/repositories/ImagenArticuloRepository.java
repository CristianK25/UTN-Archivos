package com.example.buensaborback.repositories;

import com.example.buensaborback.domain.entities.ImagenArticulo;
import org.springframework.stereotype.Repository;

@Repository
public interface ImagenArticuloRepository extends BaseRepository<ImagenArticulo,Long>{
}
