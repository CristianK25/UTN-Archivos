package org.springej.backende_commerce;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BackendECommerceApplication {

    public static void main(String[] args) {
        SpringApplication.run(BackendECommerceApplication.class, args);
    }

}
