package org.springej.backende_commerce.Constantes;

public class JwtConstantes {
    // 7 dias
    public static final long JWT_EXPIRATION_TIME = 1000L * 60 * 60 * 24 * 7;

}
