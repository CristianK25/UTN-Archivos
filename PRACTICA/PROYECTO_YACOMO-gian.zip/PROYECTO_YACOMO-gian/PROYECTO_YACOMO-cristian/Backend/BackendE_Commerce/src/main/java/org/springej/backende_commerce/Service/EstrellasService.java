package org.springej.backende_commerce.Service;

import org.springframework.stereotype.Service;

@Service
public class EstrellasService {
}
