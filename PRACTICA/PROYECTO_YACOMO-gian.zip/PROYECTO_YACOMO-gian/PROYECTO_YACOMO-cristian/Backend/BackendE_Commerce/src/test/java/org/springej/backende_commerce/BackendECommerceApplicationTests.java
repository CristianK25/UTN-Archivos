package org.springej.backende_commerce;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BackendECommerceApplicationTests {

    @Test
    void contextLoads() {
    }

}
